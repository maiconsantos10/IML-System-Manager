package ui;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import entities.Caso;
import entities.Corpo;


public class CadastroCorpoFrame extends JFrame {

	public CadastroCorpoFrame() {
		setTitle("Registrar corpo");
		setSize(400,300);
		setLocationRelativeTo(null);
		
		JPanel panel = new JPanel(new GridLayout(4,2));
		
		panel.add(new JLabel("Nome: "));
		JTextField campoNome = new JTextField();
		panel.add(campoNome);
		
		panel.add(new JLabel("Causa da morte: "));
		JTextField campoCausa = new JTextField();
		panel.add(campoCausa);	
		
		JButton btnSalvar = new JButton("Salvar");
		btnSalvar.addActionListener(e -> {
			String nome = campoNome.getText();
			String causa = campoCausa.getText();
			
			Corpo corpo = new Corpo(1, nome, causa);
			
			Caso caso = new Caso(1, causa, corpo);
			
			System.out.println("Caso registrado: " + nome + "\nCausa: " + causa + "\n-----");
		});
		
		panel.add(btnSalvar);
			
		add(panel);
		
		setVisible(true);
		
		
		}
}
